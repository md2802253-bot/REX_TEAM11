const fs = require('fs');
const path = require('path');
const JSZip = require('jszip');

async function buildZip() {
  const tsContent = fs.readFileSync(path.join(__dirname, '../src/androidProject/projectFiles.ts'), 'utf8');
  
  // Extract path and content
  const regex = /path:\s*['"]([^'"]+)['"][\s\S]*?content:\s*`([\s\S]*?)`\s*,/g;
  let match;
  const zip = new JSZip();
  const folder = zip.folder('REX_Team_Android_Source');
  
  let count = 0;
  while ((match = regex.exec(tsContent)) !== null) {
    const filePath = match[1];
    const fileContent = match[2];
    folder.file(filePath, fileContent);
    count++;
  }
  
  // Also add gradle wrapper
  folder.file(
    'gradle/wrapper/gradle-wrapper.properties',
    `distributionBase=GRADLE_USER_HOME\ndistributionPath=wrapper/dists\ndistributionUrl=https\\://services.gradle.org/distributions/gradle-8.5-bin.zip\nnetworkTimeout=10000\nvalidateDistributionUrl=true\n`
  );
  
  const buffer = await zip.generateAsync({ type: 'nodebuffer' });
  fs.writeFileSync(path.join(__dirname, '../public/REX_Team_Android_Source.zip'), buffer);
  console.log(`Generated public/REX_Team_Android_Source.zip with ${count} files.`);
}

buildZip().catch(console.error);
