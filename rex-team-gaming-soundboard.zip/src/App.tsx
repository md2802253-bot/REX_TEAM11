import React, { useState, useEffect } from 'react';
import {
  Volume2,
  Layers,
  Smartphone,
  Radio,
  Download,
  Info,
  Shield,
  Headphones,
  Sliders,
  Sparkles,
} from 'lucide-react';
import { RexLogo } from './components/RexLogo';
import { AudioUploader } from './components/AudioUploader';
import { SoundboardGrid } from './components/SoundboardGrid';
import { MicRoutingGuide } from './components/MicRoutingGuide';
import { FloatingOverlaySimulator } from './components/FloatingOverlaySimulator';
import { AndroidSourceExporter } from './components/AndroidSourceExporter';
import { SoundItem } from './types';
import { getAllSounds } from './utils/audioStorage';

export default function App() {
  const [activeTab, setActiveTab] = useState<'soundboard' | 'overlay' | 'mic_guide' | 'android_code'>('soundboard');
  const [sounds, setSounds] = useState<SoundItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [masterVolume, setMasterVolume] = useState(0.85);
  const [activeSound, setActiveSound] = useState<SoundItem | null>(null);

  // Load persistent sounds from IndexedDB on startup
  const refreshSounds = async () => {
    try {
      const items = await getAllSounds();
      setSounds(items);
    } catch (err) {
      console.error('Failed to load sounds:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    refreshSounds();
  }, []);

  return (
    <div className="min-h-screen bg-[#08090d] text-slate-100 selection:bg-red-500 selection:text-white pb-16">
      {/* Top Gaming Navigation Header */}
      <header className="sticky top-0 z-40 border-b border-slate-800/80 bg-[#0a0b12]/90 backdrop-blur-md shadow-2xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <div className="cursor-pointer" onClick={() => setActiveTab('soundboard')}>
              <RexLogo size="md" />
            </div>

            {/* Navigation Tabs */}
            <nav className="flex items-center gap-1 sm:gap-2">
              <button
                onClick={() => setActiveTab('soundboard')}
                className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl font-chakra font-bold text-xs sm:text-sm tracking-wider uppercase transition-all ${
                  activeTab === 'soundboard'
                    ? 'bg-gradient-to-r from-red-600 to-rose-700 text-white shadow-[0_0_20px_rgba(255,30,68,0.5)] border border-red-500/50'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <Volume2 className="w-4 h-4 text-cyan-400" />
                <span>Soundboard</span>
                {sounds.length > 0 && (
                  <span className="hidden sm:inline-block px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-black/40 text-cyan-300 border border-cyan-500/40">
                    {sounds.length}
                  </span>
                )}
              </button>

              <button
                onClick={() => setActiveTab('overlay')}
                className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl font-chakra font-bold text-xs sm:text-sm tracking-wider uppercase transition-all ${
                  activeTab === 'overlay'
                    ? 'bg-gradient-to-r from-cyan-600 to-blue-700 text-white shadow-[0_0_20px_rgba(0,229,255,0.5)] border border-cyan-400/50'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <Smartphone className="w-4 h-4 text-red-400" />
                <span className="hidden md:inline">In-Game</span>
                <span>Overlay</span>
              </button>

              <button
                onClick={() => setActiveTab('mic_guide')}
                className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl font-chakra font-bold text-xs sm:text-sm tracking-wider uppercase transition-all ${
                  activeTab === 'mic_guide'
                    ? 'bg-gradient-to-r from-purple-600 to-indigo-700 text-white shadow-[0_0_20px_rgba(168,85,247,0.5)] border border-purple-400/50'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <Radio className="w-4 h-4 text-yellow-400" />
                <span className="hidden md:inline">Free Fire</span>
                <span>Mic Setup</span>
              </button>

              <button
                onClick={() => setActiveTab('android_code')}
                className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl font-chakra font-bold text-xs sm:text-sm tracking-wider uppercase transition-all ${
                  activeTab === 'android_code'
                    ? 'bg-gradient-to-r from-emerald-600 to-teal-700 text-white shadow-[0_0_20px_rgba(16,185,129,0.5)] border border-emerald-400/50'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <Download className="w-4 h-4 text-emerald-400" />
                <span className="hidden md:inline">Android</span>
                <span>Source & APK</span>
              </button>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {/* TAB 1: Soundboard */}
        {activeTab === 'soundboard' && (
          <div className="space-y-6">
            {/* Audio Uploader Box */}
            <AudioUploader
              onSoundsAdded={refreshSounds}
              hasSounds={sounds.length > 0}
            />

            {/* Soundboard Grid Console */}
            {isLoading ? (
              <div className="text-center py-16 text-slate-500 font-mono text-sm">
                সাউন্ডবোর্ড লোড হচ্ছে... (Loading audio library...)
              </div>
            ) : (
              <SoundboardGrid
                sounds={sounds}
                onRefreshSounds={refreshSounds}
                masterVolume={masterVolume}
                onMasterVolumeChange={setMasterVolume}
                onPlayStateChange={(_, sound) => setActiveSound(sound)}
              />
            )}
          </div>
        )}

        {/* TAB 2: Free Fire Overlay Simulator */}
        {activeTab === 'overlay' && (
          <FloatingOverlaySimulator
            sounds={sounds}
            onPlaySound={(s) => {
              // Trigger play on this sound
              setActiveSound(s);
              const audio = new Audio(s.url);
              audio.volume = masterVolume;
              audio.play();
            }}
            onStopAll={() => {
              setActiveSound(null);
            }}
            activeSoundId={activeSound?.id || null}
          />
        )}

        {/* TAB 3: Free Fire Mic Audio Architecture & Hardware Guide */}
        {activeTab === 'mic_guide' && <MicRoutingGuide />}

        {/* TAB 4: Android Project Source Explorer & ZIP Downloader */}
        {activeTab === 'android_code' && <AndroidSourceExporter />}
      </main>
    </div>
  );
}
