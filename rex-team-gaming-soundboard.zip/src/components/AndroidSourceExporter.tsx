import React, { useState } from 'react';
import JSZip from 'jszip';
import {
  Download,
  FileCode,
  Folder,
  Copy,
  Check,
  Terminal,
  Cpu,
  Layers,
  Sparkles,
  ExternalLink,
  BookOpen,
} from 'lucide-react';
import { ANDROID_PROJECT_FILES } from '../androidProject/projectFiles';
import { AndroidFileItem } from '../types';

export const AndroidSourceExporter: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<AndroidFileItem>(ANDROID_PROJECT_FILES[5]); // Default to MainActivity.java
  const [isCopied, setIsCopied] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const downloadProjectZip = async () => {
    setIsExporting(true);
    setDownloadSuccess(false);

    try {
      const zip = new JSZip();
      const rootFolder = zip.folder('REX_Team_Android_Source');

      if (rootFolder) {
        for (const file of ANDROID_PROJECT_FILES) {
          rootFolder.file(file.path, file.content);
        }

        // Add gradle wrapper properties
        const gradleWrapper = rootFolder.folder('gradle/wrapper');
        if (gradleWrapper) {
          gradleWrapper.file(
            'gradle-wrapper.properties',
            `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.5-bin.zip
networkTimeout=10000
validateDistributionUrl=true
`
          );
        }
      }

      const content = await zip.generateAsync({ type: 'blob' });
      const downloadUrl = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = 'REX_Team_Android_Source.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(downloadUrl);

      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 4000);
    } catch (err) {
      console.error('Failed to create zip', err);
      alert('ZIP তৈরি করতে ব্যর্থ হয়েছে। দয়া করে পুনরায় চেষ্টা করুন।');
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Download Action Banner */}
      <div className="relative overflow-hidden rounded-2xl border border-cyan-500/40 bg-gradient-to-r from-[#0d101a] via-[#121626] to-[#150d18] p-6 shadow-2xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-cyan-500 text-black">
                PRODUCTION READY
              </span>
              <span className="text-xs text-red-400 font-mono">Native Android Studio Project</span>
            </div>
            <h3 className="font-orbitron text-2xl font-black text-white">
              REX Team Android Source Code & APK Builder
            </h3>
            <p className="text-sm text-slate-300 max-w-2xl">
              কমপ্লিট নেটিভ অ্যান্ড্রয়েড সোর্স কোড। আধুনিক ফাইল পিকার, পারসিস্টেন্ট প্রাইভেট স্টোরেজ, ফ্লোটিং ওভারলে এবং মেটেরিয়াল গেমিং থিম সহ।
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3">
            <button
              onClick={downloadProjectZip}
              disabled={isExporting}
              className="w-full sm:w-auto flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white font-orbitron font-bold text-sm tracking-wide shadow-[0_0_25px_rgba(255,30,68,0.5)] hover:from-red-500 hover:to-rose-500 transition-all disabled:opacity-50"
            >
              <Download className="w-5 h-5" />
              <span>{isExporting ? 'Packaging ZIP...' : 'Download Project (.ZIP)'}</span>
            </button>
          </div>
        </div>

        {downloadSuccess && (
          <div className="mt-4 p-3 rounded-xl bg-emerald-950/60 border border-emerald-500 text-xs text-emerald-300 flex items-center gap-2 font-mono">
            <Check className="w-4 h-4 text-emerald-400" />
            <span>REX_Team_Android_Source.zip সফলভাবে ডাউনলোড হয়েছে! Android Studio-তে ওপেন করুন।</span>
          </div>
        )}
      </div>

      {/* Code Browser Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 rounded-2xl border border-slate-800 bg-[#0c0e17] overflow-hidden shadow-2xl">
        {/* Left Sidebar: File Tree */}
        <div className="lg:col-span-4 border-r border-slate-800/80 bg-[#090b12] p-4 flex flex-col gap-2">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <span className="font-chakra text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Folder className="w-4 h-4 text-cyan-400" /> Project Structure
            </span>
            <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/50">
              {ANDROID_PROJECT_FILES.length} Files
            </span>
          </div>

          <div className="space-y-1 overflow-y-auto max-h-[500px] pr-1">
            {ANDROID_PROJECT_FILES.map((file) => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-left text-xs font-mono transition-all ${
                    isSelected
                      ? 'bg-red-950/50 text-white border border-red-500/60 shadow-[0_0_12px_rgba(255,30,68,0.25)]'
                      : 'text-slate-400 hover:bg-[#141725] hover:text-slate-200'
                  }`}
                >
                  <FileCode
                    className={`w-4 h-4 shrink-0 ${
                      isSelected ? 'text-red-400' : 'text-slate-500'
                    }`}
                  />
                  <div className="truncate">
                    <div className="truncate font-bold">{file.name}</div>
                    <div className="text-[10px] text-slate-500 truncate">{file.description}</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Editor: Code Viewer */}
        <div className="lg:col-span-8 flex flex-col bg-[#0b0d16]">
          {/* Editor Header */}
          <div className="flex items-center justify-between px-5 py-3 border-b border-slate-800 bg-[#0e101c]">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
              <span className="w-2.5 h-2.5 rounded-full bg-yellow-500" />
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span className="ml-3 font-mono text-xs text-cyan-400 font-bold">
                {selectedFile.path}
              </span>
            </div>

            <button
              onClick={handleCopyCode}
              className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-300 transition-colors"
            >
              {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{isCopied ? 'Copied!' : 'Copy Code'}</span>
            </button>
          </div>

          {/* Code Viewer Body */}
          <div className="p-4 overflow-auto max-h-[500px] text-xs font-mono leading-relaxed bg-[#08090f]">
            <pre className="text-slate-300 select-all whitespace-pre">
              <code>{selectedFile.content}</code>
            </pre>
          </div>
        </div>
      </div>

      {/* Step-by-Step Compilation Guide */}
      <div className="rounded-2xl border border-slate-800 bg-[#0e111c] p-6 space-y-4">
        <h4 className="font-orbitron text-lg font-bold text-white flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-cyan-400" />
          Android Studio-তে APK তৈরি করার সহজ নিয়ম (Step-by-Step Guide)
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-2">
          <div className="p-4 rounded-xl bg-[#131625] border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-orbitron font-bold text-xs text-red-400">STEP 1</span>
              <span className="text-xs text-slate-500">Unzip</span>
            </div>
            <h5 className="font-chakra font-bold text-white text-sm">প্রজেক্ট আনজিপ করুন</h5>
            <p className="text-xs text-slate-400">
              উপরের <strong className="text-cyan-400">Download Project (.ZIP)</strong> বাটন থেকে ফাইলটি ডাউনলোড করে আপনার পিসিতে আনজিপ করুন।
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#131625] border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-orbitron font-bold text-xs text-cyan-400">STEP 2</span>
              <span className="text-xs text-slate-500">Open Studio</span>
            </div>
            <h5 className="font-chakra font-bold text-white text-sm">Android Studio-তে ওপেন</h5>
            <p className="text-xs text-slate-400">
              Android Studio ওপেন করে <strong>File &gt; Open</strong> চাপুন এবং <code className="text-cyan-300">REX_Team_Android_Source</code> ফোল্ডারটি নির্বাচন করুন।
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#131625] border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-orbitron font-bold text-xs text-purple-400">STEP 3</span>
              <span className="text-xs text-slate-500">Build APK</span>
            </div>
            <h5 className="font-chakra font-bold text-white text-sm">Build APK চাপুন</h5>
            <p className="text-xs text-slate-400">
              টপ মেনু থেকে <strong>Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</strong> চাপুন। Gradle স্বয়ংক্রিয়ভাবে কম্পাইল করবে।
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#131625] border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-orbitron font-bold text-xs text-emerald-400">STEP 4</span>
              <span className="text-xs text-slate-500">Install</span>
            </div>
            <h5 className="font-chakra font-bold text-white text-sm">ফোনে ইন্সটল করুন</h5>
            <p className="text-xs text-slate-400">
              APK ফাইলটি পাবেন: <br />
              <code className="text-[10px] text-emerald-300 break-all">app/build/outputs/apk/debug/app-debug.apk</code>
            </p>
          </div>
        </div>

        {/* Command Line Terminal tip */}
        <div className="p-3.5 rounded-xl bg-black/60 border border-slate-800 text-xs font-mono text-slate-400 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>কমান্ড লাইন দিয়ে তৈরি করতে চাইলে টার্মিনালে চালান:</span>
            <code className="text-cyan-300 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
              ./gradlew assembleDebug
            </code>
          </div>
        </div>
      </div>
    </div>
  );
};
