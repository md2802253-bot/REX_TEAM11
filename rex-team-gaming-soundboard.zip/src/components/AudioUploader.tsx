import React, { useRef, useState } from 'react';
import { UploadCloud, Music, Plus, Sparkles } from 'lucide-react';
import { SoundItem } from '../types';
import { saveSound } from '../utils/audioStorage';
import { createGamingSound } from '../utils/synthesizer';

interface AudioUploaderProps {
  onSoundsAdded: () => void;
  hasSounds: boolean;
}

export const AudioUploader: React.FC<AudioUploaderProps> = ({ onSoundsAdded, hasSounds }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSynthesizing, setIsSynthesizing] = useState(false);

  const processFiles = async (files: FileList | File[]) => {
    setIsProcessing(true);
    const audioFiles = Array.from(files).filter((file) =>
      file.type.startsWith('audio/') ||
      /\.(mp3|wav|ogg|aac|m4a|flac|opus|weba)$/i.test(file.name)
    );

    if (audioFiles.length === 0) {
      alert('অনুগ্রহ করে অডিও ফাইল (MP3, WAV, OGG, ইত্যাদি) নির্বাচন করুন।');
      setIsProcessing(false);
      return;
    }

    for (const file of audioFiles) {
      const cleanName = file.name.replace(/\.[^/.]+$/, '');
      const id = 'snd_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);

      // Estimate duration with Audio element
      let duration = 0;
      try {
        const tempUrl = URL.createObjectURL(file);
        const tempAudio = new Audio(tempUrl);
        await new Promise((res) => {
          tempAudio.onloadedmetadata = () => {
            duration = tempAudio.duration;
            res(true);
          };
          tempAudio.onerror = () => res(false);
          setTimeout(() => res(false), 2000); // 2s timeout
        });
        URL.revokeObjectURL(tempUrl);
      } catch (err) {
        console.warn('Could not read audio duration', err);
      }

      const item: Omit<SoundItem, 'url'> = {
        id,
        name: cleanName,
        blob: file,
        duration,
        size: file.size,
        type: file.type || 'audio/mpeg',
        createdAt: Date.now(),
      };

      await saveSound(item);
    }

    setIsProcessing(false);
    onSoundsAdded();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFiles(e.dataTransfer.files);
    }
  };

  const handleAddSamplePack = async () => {
    setIsSynthesizing(true);
    try {
      const samples: ('headshot' | 'victory' | 'airhorn' | 'cyber_alarm' | 'laser')[] = [
        'headshot',
        'victory',
        'airhorn',
        'cyber_alarm',
        'laser',
      ];

      for (const s of samples) {
        const soundData = await createGamingSound(s);
        const id = 'snd_sample_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
        await saveSound({
          id,
          name: soundData.name,
          blob: soundData.blob,
          duration: soundData.duration,
          size: soundData.blob.size,
          type: 'audio/wav',
          createdAt: Date.now(),
        });
      }
      onSoundsAdded();
    } catch (err) {
      console.error('Error generating sample sounds:', err);
    } finally {
      setIsSynthesizing(false);
    }
  };

  return (
    <div className="w-full">
      <input
        ref={fileInputRef}
        type="file"
        accept="audio/*,.mp3,.wav,.ogg,.aac,.m4a,.flac"
        multiple
        className="hidden"
        onChange={(e) => {
          if (e.target.files && e.target.files.length > 0) {
            processFiles(e.target.files);
          }
        }}
      />

      {/* Main Upload Dropzone */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`group relative cursor-pointer rounded-2xl border-2 border-dashed p-6 text-center transition-all duration-300 ${
          isDragging
            ? 'border-cyan-400 bg-cyan-950/30 shadow-[0_0_25px_rgba(0,229,255,0.3)]'
            : hasSounds
            ? 'border-slate-800 bg-[#0d0f18]/80 hover:border-red-500/60 hover:bg-[#131624]'
            : 'border-red-500/50 bg-[#12141f] shadow-[0_0_30px_rgba(255,30,68,0.15)] hover:border-red-400 hover:shadow-[0_0_35px_rgba(255,30,68,0.25)]'
        }`}
      >
        <div className="flex flex-col items-center justify-center gap-3">
          <div className="relative flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-red-600/20 to-cyan-500/20 border border-slate-700/80 group-hover:scale-105 group-hover:border-red-500 transition-all">
            <UploadCloud className="h-7 w-7 text-red-400 group-hover:text-cyan-300 transition-colors" />
            <div className="absolute -bottom-1 -right-1 rounded-full bg-cyan-500 p-1 text-black">
              <Plus className="h-3 w-3 stroke-[3]" />
            </div>
          </div>

          <div className="space-y-1">
            <p className="font-chakra text-lg font-bold tracking-wide text-white group-hover:text-red-400 transition-colors">
              {isProcessing
                ? 'সাউন্ড প্রসেস করা হচ্ছে... (Processing Audio...)'
                : '＋ সাউন্ড ফাইল আপলোড করুন (Upload MP3 / WAV)'}
            </p>
            <p className="text-xs text-slate-400">
              ফাইল সিলেক্ট করতে ক্লিক করুন অথবা ড্র্যাগ & ড্রপ করুন • আনলিমিটেড সাউন্ড সাপোর্ট
            </p>
            <div className="flex items-center justify-center gap-2 pt-1">
              <span className="rounded bg-slate-800/80 px-2 py-0.5 text-[11px] font-mono text-cyan-400 border border-slate-700">
                MP3
              </span>
              <span className="rounded bg-slate-800/80 px-2 py-0.5 text-[11px] font-mono text-cyan-400 border border-slate-700">
                WAV
              </span>
              <span className="rounded bg-slate-800/80 px-2 py-0.5 text-[11px] font-mono text-cyan-400 border border-slate-700">
                OGG
              </span>
              <span className="rounded bg-slate-800/80 px-2 py-0.5 text-[11px] font-mono text-cyan-400 border border-slate-700">
                AAC
              </span>
              <span className="rounded bg-slate-800/80 px-2 py-0.5 text-[11px] font-mono text-cyan-400 border border-slate-700">
                M4A
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Optional Quick Test Generator for immediate fun */}
      {!hasSounds && (
        <div className="mt-4 flex items-center justify-between rounded-xl border border-slate-800 bg-[#0d0f19] p-3 text-xs">
          <div className="flex items-center gap-2.5 text-slate-300">
            <Sparkles className="h-4 w-4 text-cyan-400 shrink-0" />
            <span>কোনো অডিও ফাইল নেই? ইনস্ট্যান্ট টেস্ট করতে চান?</span>
          </div>
          <button
            onClick={handleAddSamplePack}
            disabled={isSynthesizing}
            className="flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-red-600 to-rose-700 px-3 py-1.5 font-chakra text-xs font-bold text-white shadow-md hover:from-red-500 hover:to-rose-600 transition-all disabled:opacity-50"
          >
            {isSynthesizing ? 'তৈরি হচ্ছে...' : '⚡ Generate 5 Gaming SFX'}
          </button>
        </div>
      )}
    </div>
  );
};
